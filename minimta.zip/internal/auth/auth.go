package auth

import (
	"encoding/json"
	"fmt"
	"os"
	"sync"
)

// User represents a user in the authentication system
type User struct {
	Username string `json:"username"`
	Password string `json:"password"` // plaintext password
	Email    string `json:"email"`
	Active   bool   `json:"active"`
}

// AuthManager handles user authentication
type AuthManager struct {
	users     map[string]*User
	usersFile string
	mutex     sync.RWMutex
}

// NewAuthManager creates a new authentication manager
func NewAuthManager(usersFile string) *AuthManager {
	return &AuthManager{
		users:     make(map[string]*User),
		usersFile: usersFile,
	}
}

// LoadUsers loads users from the JSON file
func (am *AuthManager) LoadUsers() error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	// Check if file exists
	if _, err := os.Stat(am.usersFile); os.IsNotExist(err) {
		// Create empty users file if it doesn't exist
		return am.saveUsers()
	}

	data, err := os.ReadFile(am.usersFile)
	if err != nil {
		return fmt.Errorf("failed to read users file: %w", err)
	}

	var users []User
	if err := json.Unmarshal(data, &users); err != nil {
		return fmt.Errorf("failed to unmarshal users: %w", err)
	}

	// Convert slice to map
	am.users = make(map[string]*User)
	for i := range users {
		am.users[users[i].Username] = &users[i]
	}

	return nil
}

// saveUsers saves users to the JSON file
func (am *AuthManager) saveUsers() error {
	// Convert map to slice
	users := make([]User, 0, len(am.users))
	for _, user := range am.users {
		users = append(users, *user)
	}

	data, err := json.MarshalIndent(users, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal users: %w", err)
	}

	if err := os.WriteFile(am.usersFile, data, 0600); err != nil {
		return fmt.Errorf("failed to write users file: %w", err)
	}

	return nil
}

// Authenticate authenticates a user with username and password
func (am *AuthManager) Authenticate(username, password string) bool {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	user, exists := am.users[username]
	if !exists || !user.Active {
		return false
	}

	// Simple plaintext comparison
	return user.Password == password
}

// AddUser adds a new user
func (am *AuthManager) AddUser(username, password, email string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	// Check if user already exists
	if _, exists := am.users[username]; exists {
		return fmt.Errorf("user %s already exists", username)
	}

	// Create user
	user := &User{
		Username: username,
		Password: password, // Store plaintext password
		Email:    email,
		Active:   true,
	}

	am.users[username] = user

	// Save to file
	return am.saveUsers()
}

// UpdateUser updates an existing user
func (am *AuthManager) UpdateUser(username, password, email string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	user, exists := am.users[username]
	if !exists {
		return fmt.Errorf("user %s does not exist", username)
	}

	// Update fields
	if password != "" {
		user.Password = password // Store plaintext password
	}

	if email != "" {
		user.Email = email
	}

	// Save to file
	return am.saveUsers()
}

// DeleteUser deletes a user
func (am *AuthManager) DeleteUser(username string) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	if _, exists := am.users[username]; !exists {
		return fmt.Errorf("user %s does not exist", username)
	}

	delete(am.users, username)

	// Save to file
	return am.saveUsers()
}

// SetUserActive sets the active status of a user
func (am *AuthManager) SetUserActive(username string, active bool) error {
	am.mutex.Lock()
	defer am.mutex.Unlock()

	user, exists := am.users[username]
	if !exists {
		return fmt.Errorf("user %s does not exist", username)
	}

	user.Active = active

	// Save to file
	return am.saveUsers()
}

// ListUsers returns a list of all users
func (am *AuthManager) ListUsers() []User {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	users := make([]User, 0, len(am.users))
	for _, user := range am.users {
		// Don't expose password hash
		userCopy := *user
		userCopy.Password = "[HIDDEN]"
		users = append(users, userCopy)
	}

	return users
}

// GetUser returns a user by username
func (am *AuthManager) GetUser(username string) (*User, bool) {
	am.mutex.RLock()
	defer am.mutex.RUnlock()

	user, exists := am.users[username]
	if !exists {
		return nil, false
	}

	// Return a copy without password hash
	userCopy := *user
	userCopy.Password = "[HIDDEN]"
	return &userCopy, true
}
