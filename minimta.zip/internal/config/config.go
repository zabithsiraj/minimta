package config

import (
	"fmt"
	"time"

	"github.com/spf13/viper"
)

// Config holds all configuration for MiniMTA
type Config struct {
	Server   ServerConfig   `mapstructure:"server"`
	TLS      TLSConfig      `mapstructure:"tls"`
	DKIM     DKIMConfig     `mapstructure:"dkim"`
	Queue    QueueConfig    `mapstructure:"queue"`
	Delivery DeliveryConfig `mapstructure:"delivery"`
	Auth     AuthConfig     `mapstructure:"auth"`
}

// ServerConfig holds server-specific configuration
type ServerConfig struct {
	Hostname     string `mapstructure:"hostname"`
	ListenAddr   string `mapstructure:"listen_addr"`
	MaxMsgSize   int64  `mapstructure:"max_message_size"`
	ReadTimeout  int    `mapstructure:"read_timeout"`
	WriteTimeout int    `mapstructure:"write_timeout"`
}

// TLSConfig holds TLS certificate configuration
type TLSConfig struct {
	CertFile string `mapstructure:"cert_file"`
	KeyFile  string `mapstructure:"key_file"`
}

// DKIMConfig holds DKIM signing configuration
type DKIMConfig struct {
	KeyPath   string `mapstructure:"key_path"`
	Selector  string `mapstructure:"selector"`
	Domain    string `mapstructure:"domain"`
	Algorithm string `mapstructure:"algorithm"`
}

// QueueConfig holds queue directory configuration
type QueueConfig struct {
	QueueDir     string `mapstructure:"queue_dir"`
	SpoolDir     string `mapstructure:"spool_dir"`
	DeliveredDir string `mapstructure:"delivered_dir"`
	BouncedDir   string `mapstructure:"bounced_dir"`
}

// DeliveryConfig holds delivery worker configuration
type DeliveryConfig struct {
	MaxRetries     int           `mapstructure:"max_retries"`
	RetryInterval  time.Duration `mapstructure:"retry_interval"`
	MaxRetryDelay  time.Duration `mapstructure:"max_retry_delay"`
	ConnectTimeout time.Duration `mapstructure:"connect_timeout"`
	CommandTimeout time.Duration `mapstructure:"command_timeout"`
	TLSOptional    bool          `mapstructure:"tls_optional"`
	MaxConcurrency int           `mapstructure:"max_concurrency"`
	WorkerInterval time.Duration `mapstructure:"worker_interval"`
}

// AuthConfig holds authentication configuration
type AuthConfig struct {
	UsersFile string `mapstructure:"users_file"`
}

// Load loads configuration from file and environment variables
func Load(configPath string) (*Config, error) {
	viper.SetConfigFile(configPath)
	viper.SetConfigType("yaml")

	// Set defaults
	setDefaults()

	// Enable reading from environment variables
	viper.AutomaticEnv()

	// Read config file
	if err := viper.ReadInConfig(); err != nil {
		return nil, fmt.Errorf("failed to read config file: %w", err)
	}

	var config Config
	if err := viper.Unmarshal(&config); err != nil {
		return nil, fmt.Errorf("failed to unmarshal config: %w", err)
	}

	return &config, nil
}

// setDefaults sets default configuration values
func setDefaults() {
	// Server defaults
	viper.SetDefault("server.hostname", "localhost")
	viper.SetDefault("server.listen_addr", "0.0.0.0:587")
	viper.SetDefault("server.max_message_size", 10485760) // 10MB
	viper.SetDefault("server.read_timeout", 30)
	viper.SetDefault("server.write_timeout", 30)

	// TLS defaults
	viper.SetDefault("tls.cert_file", "/etc/minimta/cert.pem")
	viper.SetDefault("tls.key_file", "/etc/minimta/key.pem")

	// DKIM defaults
	viper.SetDefault("dkim.algorithm", "rsa-sha256")

	// Queue defaults
	viper.SetDefault("queue.queue_dir", "./queue")
	viper.SetDefault("queue.spool_dir", "./spool")
	viper.SetDefault("queue.delivered_dir", "./delivered")
	viper.SetDefault("queue.bounced_dir", "./bounced")

	// Delivery defaults
	viper.SetDefault("delivery.max_retries", 5)
	viper.SetDefault("delivery.retry_interval", "5m")
	viper.SetDefault("delivery.max_retry_delay", "1h")
	viper.SetDefault("delivery.connect_timeout", "30s")
	viper.SetDefault("delivery.command_timeout", "5m")
	viper.SetDefault("delivery.tls_optional", false)
	viper.SetDefault("delivery.max_concurrency", 10)
	viper.SetDefault("delivery.worker_interval", "30s")

	// Auth defaults
	viper.SetDefault("auth.users_file", "./users.json")
}
