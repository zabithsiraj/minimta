package delivery

import (
	"crypto/tls"
	"fmt"
	"net"
	"net/smtp"
	"strings"
	"time"

	"minimta/internal/log"

	"github.com/miekg/dns"
	"go.uber.org/zap"
)

// DeliveryResult represents the result of a delivery attempt
type DeliveryResult struct {
	Success bool
	Error   string
	Bounce  bool
}

// DeliveryManager handles SMTP delivery of messages
type DeliveryManager struct {
	connectTimeout time.Duration
	commandTimeout time.Duration
	tlsOptional    bool
	maxRetries     int
	retryInterval  time.Duration
	maxRetryDelay  time.Duration
}

// NewDeliveryManager creates a new delivery manager
func NewDeliveryManager(connectTimeout, commandTimeout time.Duration, tlsOptional bool, maxRetries int, retryInterval, maxRetryDelay time.Duration) *DeliveryManager {
	return &DeliveryManager{
		connectTimeout: connectTimeout,
		commandTimeout: commandTimeout,
		tlsOptional:    tlsOptional,
		maxRetries:     maxRetries,
		retryInterval:  retryInterval,
		maxRetryDelay:  maxRetryDelay,
	}
}

// DeliverMessage attempts to deliver a message to the specified recipients
func (dm *DeliveryManager) DeliverMessage(from string, recipients []string, messageData []byte) *DeliveryResult {
	log.Info("Starting delivery",
		zap.String("from", from),
		zap.Strings("recipients", recipients))

	// Group recipients by domain
	domainGroups := dm.groupRecipientsByDomain(recipients)

	var lastError error
	var hasSuccess bool

	for domain, domainRecipients := range domainGroups {
		result := dm.deliverToDomain(from, domain, domainRecipients, messageData)
		if result.Success {
			hasSuccess = true
		} else {
			lastError = fmt.Errorf("delivery to %s failed: %s", domain, result.Error)
		}
	}

	if hasSuccess {
		return &DeliveryResult{Success: true}
	}

	return &DeliveryResult{
		Success: false,
		Error:   lastError.Error(),
		Bounce:  true,
	}
}

// groupRecipientsByDomain groups recipients by their domain
func (dm *DeliveryManager) groupRecipientsByDomain(recipients []string) map[string][]string {
	groups := make(map[string][]string)

	for _, recipient := range recipients {
		parts := strings.Split(recipient, "@")
		if len(parts) != 2 {
			continue
		}
		domain := strings.ToLower(parts[1])
		groups[domain] = append(groups[domain], recipient)
	}

	return groups
}

// deliverToDomain delivers messages to all recipients in a domain
func (dm *DeliveryManager) deliverToDomain(from, domain string, recipients []string, messageData []byte) *DeliveryResult {
	log.Info("Delivering to domain",
		zap.String("domain", domain),
		zap.Strings("recipients", recipients))

	// Look up MX records
	mxHosts, err := dm.lookupMX(domain)
	if err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("MX lookup failed: %v", err),
			Bounce:  true,
		}
	}

	if len(mxHosts) == 0 {
		return &DeliveryResult{
			Success: false,
			Error:   "No MX records found",
			Bounce:  true,
		}
	}

	// Try each MX host
	var lastError error
	for _, mxHost := range mxHosts {
		result := dm.deliverToHost(from, mxHost, recipients, messageData)
		if result.Success {
			return result
		}
		lastError = fmt.Errorf("delivery to %s failed: %s", mxHost, result.Error)
	}

	return &DeliveryResult{
		Success: false,
		Error:   lastError.Error(),
		Bounce:  false, // Don't bounce if we can try other MX hosts
	}
}

// deliverToHost delivers messages to a specific MX host
func (dm *DeliveryManager) deliverToHost(from, host string, recipients []string, messageData []byte) *DeliveryResult {
	log.Info("Delivering to host",
		zap.String("host", host),
		zap.Strings("recipients", recipients))

	// Connect to SMTP server
	conn, err := dm.connectToHost(host)
	if err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("Connection failed: %v", err),
		}
	}
	defer conn.Close()

	// Create SMTP client
	client, err := smtp.NewClient(conn, host)
	if err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("SMTP client creation failed: %v", err),
		}
	}
	defer client.Quit()

	// Check if server supports STARTTLS
	if ok, _ := client.Extension("STARTTLS"); ok {
		config := &tls.Config{
			ServerName: host,
		}

		if err := client.StartTLS(config); err != nil {
			if !dm.tlsOptional {
				return &DeliveryResult{
					Success: false,
					Error:   fmt.Sprintf("STARTTLS failed: %v", err),
				}
			}
			log.Warn("STARTTLS failed, continuing without encryption",
				zap.String("host", host),
				zap.Error(err))
		} else {
			log.Info("STARTTLS established", zap.String("host", host))
		}
	} else if !dm.tlsOptional {
		return &DeliveryResult{
			Success: false,
			Error:   "Server does not support STARTTLS",
		}
	}

	// Set sender
	if err := client.Mail(from); err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("MAIL FROM failed: %v", err),
		}
	}

	// Set recipients
	for _, recipient := range recipients {
		if err := client.Rcpt(recipient); err != nil {
			return &DeliveryResult{
				Success: false,
				Error:   fmt.Sprintf("RCPT TO failed for %s: %v", recipient, err),
			}
		}
	}

	// Send message data
	writer, err := client.Data()
	if err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("DATA command failed: %v", err),
		}
	}

	if _, err := writer.Write(messageData); err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("Failed to write message data: %v", err),
		}
	}

	if err := writer.Close(); err != nil {
		return &DeliveryResult{
			Success: false,
			Error:   fmt.Sprintf("Failed to close data writer: %v", err),
		}
	}

	log.Info("Message delivered successfully",
		zap.String("host", host),
		zap.Strings("recipients", recipients))

	return &DeliveryResult{Success: true}
}

// connectToHost establishes a connection to the SMTP host
func (dm *DeliveryManager) connectToHost(host string) (net.Conn, error) {
	// Try port 25 first, then 587
	ports := []string{"25", "587"}

	for _, port := range ports {
		address := net.JoinHostPort(host, port)

		conn, err := net.DialTimeout("tcp", address, dm.connectTimeout)
		if err != nil {
			log.Debug("Connection failed",
				zap.String("address", address),
				zap.Error(err))
			continue
		}

		log.Info("Connected to SMTP server",
			zap.String("address", address))

		return conn, nil
	}

	return nil, fmt.Errorf("failed to connect to %s on ports 25 and 587", host)
}

// lookupMX performs DNS MX lookup for a domain
func (dm *DeliveryManager) lookupMX(domain string) ([]string, error) {
	log.Debug("Looking up MX records", zap.String("domain", domain))

	// Create DNS client
	client := new(dns.Client)
	client.Net = "udp"
	client.Timeout = 5 * time.Second

	// Create MX query
	msg := new(dns.Msg)
	msg.Id = dns.Id()
	msg.RecursionDesired = true
	msg.Question = make([]dns.Question, 1)
	msg.Question[0] = dns.Question{
		Name:   dns.Fqdn(domain),
		Qtype:  dns.TypeMX,
		Qclass: dns.ClassINET,
	}

	// Send query
	response, _, err := client.Exchange(msg, "8.8.8.8:53")
	if err != nil {
		return nil, fmt.Errorf("DNS query failed: %v", err)
	}

	if response.Rcode != dns.RcodeSuccess {
		return nil, fmt.Errorf("DNS query returned error: %s", dns.RcodeToString[response.Rcode])
	}

	// Extract MX hosts
	var mxHosts []string
	for _, answer := range response.Answer {
		if mx, ok := answer.(*dns.MX); ok {
			mxHosts = append(mxHosts, strings.TrimSuffix(mx.Mx, "."))
		}
	}

	if len(mxHosts) == 0 {
		return nil, fmt.Errorf("no MX records found for %s", domain)
	}

	log.Debug("MX lookup successful",
		zap.String("domain", domain),
		zap.Strings("mx_hosts", mxHosts))

	return mxHosts, nil
}

// CalculateRetryDelay calculates the delay for the next retry attempt
func (dm *DeliveryManager) CalculateRetryDelay(attempt int) time.Duration {
	// Exponential backoff with jitter
	delay := dm.retryInterval * time.Duration(1<<uint(attempt-1))

	// Cap at maximum delay
	if delay > dm.maxRetryDelay {
		delay = dm.maxRetryDelay
	}

	return delay
}

// ShouldRetry determines if a message should be retried based on the error
func (dm *DeliveryManager) ShouldRetry(err error, attempt int) bool {
	if attempt >= dm.maxRetries {
		return false
	}

	errorStr := strings.ToLower(err.Error())

	// Don't retry for permanent failures
	permanentErrors := []string{
		"user unknown",
		"mailbox unavailable",
		"no such user",
		"invalid recipient",
		"recipient rejected",
		"no mx records",
		"domain not found",
	}

	for _, permanentError := range permanentErrors {
		if strings.Contains(errorStr, permanentError) {
			return false
		}
	}

	return true
}
