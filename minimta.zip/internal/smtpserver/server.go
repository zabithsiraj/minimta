package smtpserver

import (
	"crypto/tls"
	"fmt"
	"io"
	"time"

	"minimta/internal/auth"
	"minimta/internal/dkim"
	"minimta/internal/log"
	"minimta/internal/queue"

	"github.com/emersion/go-smtp"
	"go.uber.org/zap"
)

// Backend implements the SMTP backend
type Backend struct {
	authManager  *auth.AuthManager
	queueManager *queue.QueueManager
	dkimSigner   *dkim.Signer
	maxMsgSize   int64
}

// NewBackend creates a new SMTP backend
func NewBackend(authManager *auth.AuthManager, queueManager *queue.QueueManager, dkimSigner *dkim.Signer, maxMsgSize int64) *Backend {
	return &Backend{
		authManager:  authManager,
		queueManager: queueManager,
		dkimSigner:   dkimSigner,
		maxMsgSize:   maxMsgSize,
	}
}

// NewSession creates a new SMTP session
func (b *Backend) NewSession(c *smtp.Conn) (smtp.Session, error) {
	return &Session{
		backend: b,
		conn:    c,
	}, nil
}

// Session represents an SMTP session
type Session struct {
	backend     *Backend
	conn        *smtp.Conn
	user        string
	from        string
	recipients  []string
	messageData []byte
}

// AuthPlain handles PLAIN authentication
func (s *Session) AuthPlain(username, password string) error {
	// Authenticate user
	if !s.backend.authManager.Authenticate(username, password) {
		return fmt.Errorf("authentication failed")
	}

	s.user = username
	log.Info("User authenticated",
		zap.String("user", username),
		zap.String("mechanism", "PLAIN"),
		zap.String("remote_addr", s.getRemoteAddr()))

	return nil
}

// Mail sets the sender
func (s *Session) Mail(from string, opts *smtp.MailOptions) error {
	log.Info("MAIL FROM",
		zap.String("from", from),
		zap.String("remote_addr", s.getRemoteAddr()))

	s.from = from
	return nil
}

// Rcpt adds a recipient
func (s *Session) Rcpt(to string, opts *smtp.RcptOptions) error {
	log.Info("RCPT TO",
		zap.String("to", to),
		zap.String("remote_addr", s.getRemoteAddr()))

	s.recipients = append(s.recipients, to)
	return nil
}

// Data handles message data
func (s *Session) Data(r io.Reader) error {
	log.Info("DATA command received",
		zap.String("remote_addr", s.getRemoteAddr()))

	// Read message data
	messageData, err := io.ReadAll(r)
	if err != nil {
		return fmt.Errorf("failed to read message data: %v", err)
	}

	// Check message size
	if int64(len(messageData)) > s.backend.maxMsgSize {
		return fmt.Errorf("message too large: %d bytes (max: %d)", len(messageData), s.backend.maxMsgSize)
	}

	s.messageData = messageData

	// Sign message with DKIM if signer is available
	if s.backend.dkimSigner != nil {
		signedData, err := s.backend.dkimSigner.SignMessage(messageData)
		if err != nil {
			log.Error("DKIM signing failed", zap.Error(err))
			// Continue without DKIM signature
		} else {
			s.messageData = signedData
			log.Info("Message signed with DKIM")
		}
	}

	// Enqueue message
	message, err := s.backend.queueManager.Enqueue(s.from, s.recipients, s.messageData)
	if err != nil {
		return fmt.Errorf("failed to enqueue message: %v", err)
	}

	log.Info("Message enqueued",
		zap.String("message_id", message.ID),
		zap.String("from", s.from),
		zap.Strings("recipients", s.recipients))

	return nil
}

// Reset resets the session
func (s *Session) Reset() {
	s.from = ""
	s.recipients = nil
	s.messageData = nil
}

// Logout logs out the user
func (s *Session) Logout() error {
	log.Info("User logged out",
		zap.String("user", s.user),
		zap.String("remote_addr", s.getRemoteAddr()))
	return nil
}

// getRemoteAddr returns the remote address as a string
func (s *Session) getRemoteAddr() string {
	if conn := s.conn.Conn(); conn != nil {
		return conn.RemoteAddr().String()
	}
	return "unknown"
}

// Server represents the SMTP server
type Server struct {
	server   *smtp.Server
	certFile string
	keyFile  string
}

// NewServer creates a new SMTP server
func NewServer(addr string, backend *Backend, tlsConfig *tls.Config, certFile, keyFile string) *Server {
	s := smtp.NewServer(backend)
	s.Addr = addr
	s.Domain = "localhost"
	s.MaxRecipients = 100
	s.MaxMessageBytes = 50 * 1024 * 1024 // 50MB
	s.MaxLineLength = 1000
	s.AllowInsecureAuth = true
	s.TLSConfig = tlsConfig
	s.ReadTimeout = 30 * time.Second
	s.WriteTimeout = 30 * time.Second

	return &Server{
		server:   s,
		certFile: certFile,
		keyFile:  keyFile,
	}
}

// Start starts the SMTP server
func (s *Server) Start() error {
	log.Info("Starting SMTP server", zap.String("addr", s.server.Addr))
	return s.server.ListenAndServe()
}

// StartTLS starts the SMTP server with STARTTLS support
func (s *Server) StartTLS() error {
	log.Info("Starting SMTP server with STARTTLS support", zap.String("addr", s.server.Addr))
	return s.server.ListenAndServe()
}

// StartDirectTLS starts the SMTP server with direct TLS (SMTPS)
func (s *Server) StartDirectTLS() error {
	log.Info("Starting SMTP server with direct TLS", zap.String("addr", s.server.Addr))
	// The TLS config is already set in the server, so we can use ListenAndServeTLS without parameters
	return s.server.ListenAndServeTLS()
}

// Stop stops the SMTP server
func (s *Server) Stop() error {
	log.Info("Stopping SMTP server")
	return s.server.Close()
}
