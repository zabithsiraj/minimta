package queue

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/google/uuid"
)

// MessageState represents the state of a queued message
type MessageState string

const (
	StatePending   MessageState = "pending"
	StateDelivered MessageState = "delivered"
	StateBounced   MessageState = "bounced"
	StateRetry     MessageState = "retry"
)

// Message represents a queued email message
type Message struct {
	ID        string        `json:"id"`
	From      string        `json:"from"`
	Rcpts     []string      `json:"rcpts"`
	State     MessageState  `json:"state"`
	Attempts  int           `json:"attempts"`
	NextTry   time.Time     `json:"next_try"`
	CreatedAt time.Time     `json:"created_at"`
	SpoolPath string        `json:"spool_path"`
	Error     string        `json:"error,omitempty"`
	LastTry   time.Time     `json:"last_try,omitempty"`
}

// QueueManager manages the file-based message queue
type QueueManager struct {
	queueDir     string
	spoolDir     string
	deliveredDir string
	bouncedDir   string
	mutex        sync.RWMutex
}

// NewQueueManager creates a new queue manager
func NewQueueManager(queueDir, spoolDir, deliveredDir, bouncedDir string) *QueueManager {
	return &QueueManager{
		queueDir:     queueDir,
		spoolDir:     spoolDir,
		deliveredDir: deliveredDir,
		bouncedDir:   bouncedDir,
	}
}

// Initialize creates necessary directories
func (qm *QueueManager) Initialize() error {
	dirs := []string{qm.queueDir, qm.spoolDir, qm.deliveredDir, qm.bouncedDir}
	for _, dir := range dirs {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return fmt.Errorf("failed to create directory %s: %w", dir, err)
		}
	}
	return nil
}

// Enqueue adds a message to the queue
func (qm *QueueManager) Enqueue(from string, rcpts []string, messageData []byte) (*Message, error) {
	qm.mutex.Lock()
	defer qm.mutex.Unlock()

	// Generate unique ID
	id := uuid.New().String()

	// Create message
	message := &Message{
		ID:        id,
		From:      from,
		Rcpts:     rcpts,
		State:     StatePending,
		Attempts:  0,
		NextTry:   time.Now(),
		CreatedAt: time.Now(),
		SpoolPath: filepath.Join(qm.spoolDir, id+".eml"),
	}

	// Save message data to spool
	spoolPath := filepath.Join(qm.spoolDir, id+".eml")
	if err := os.WriteFile(spoolPath, messageData, 0644); err != nil {
		return nil, fmt.Errorf("failed to write message to spool: %w", err)
	}

	// Save message metadata
	if err := qm.saveMessage(message); err != nil {
		// Clean up spool file on error
		os.Remove(spoolPath)
		return nil, fmt.Errorf("failed to save message metadata: %w", err)
	}

	return message, nil
}

// GetPendingMessages returns all pending messages ready for delivery
func (qm *QueueManager) GetPendingMessages() ([]*Message, error) {
	qm.mutex.RLock()
	defer qm.mutex.RUnlock()

	var messages []*Message
	now := time.Now()

	err := filepath.Walk(qm.queueDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() || filepath.Ext(path) != ".json" {
			return nil
		}

		message, err := qm.loadMessage(path)
		if err != nil {
			return err
		}

		if message.State == StatePending || (message.State == StateRetry && message.NextTry.Before(now)) {
			messages = append(messages, message)
		}

		return nil
	})

	return messages, err
}

// GetMessage retrieves a message by ID
func (qm *QueueManager) GetMessage(id string) (*Message, error) {
	qm.mutex.RLock()
	defer qm.mutex.RUnlock()

	path := filepath.Join(qm.queueDir, id+".json")
	return qm.loadMessage(path)
}

// GetMessageData retrieves the raw message data
func (qm *QueueManager) GetMessageData(message *Message) ([]byte, error) {
	return os.ReadFile(message.SpoolPath)
}

// UpdateMessageState updates the state of a message
func (qm *QueueManager) UpdateMessageState(message *Message, state MessageState, errorMsg string) error {
	qm.mutex.Lock()
	defer qm.mutex.Unlock()

	message.State = state
	message.LastTry = time.Now()
	if errorMsg != "" {
		message.Error = errorMsg
	}

	return qm.saveMessage(message)
}

// IncrementAttempts increments the attempt counter and sets next retry time
func (qm *QueueManager) IncrementAttempts(message *Message, retryDelay time.Duration) error {
	qm.mutex.Lock()
	defer qm.mutex.Unlock()

	message.Attempts++
	message.NextTry = time.Now().Add(retryDelay)
	message.State = StateRetry
	message.LastTry = time.Now()

	return qm.saveMessage(message)
}

// MoveToDelivered moves a message to the delivered directory
func (qm *QueueManager) MoveToDelivered(message *Message) error {
	qm.mutex.Lock()
	defer qm.mutex.Unlock()

	// Move metadata file
	srcMeta := filepath.Join(qm.queueDir, message.ID+".json")
	dstMeta := filepath.Join(qm.deliveredDir, message.ID+".json")

	if err := os.Rename(srcMeta, dstMeta); err != nil {
		return fmt.Errorf("failed to move metadata file: %w", err)
	}

	// Move spool file
	srcSpool := message.SpoolPath
	dstSpool := filepath.Join(qm.deliveredDir, message.ID+".eml")

	if err := os.Rename(srcSpool, dstSpool); err != nil {
		return fmt.Errorf("failed to move spool file: %w", err)
	}

	// Update message paths
	message.SpoolPath = dstSpool
	message.State = StateDelivered

	return nil
}

// MoveToBounced moves a message to the bounced directory
func (qm *QueueManager) MoveToBounced(message *Message) error {
	qm.mutex.Lock()
	defer qm.mutex.Unlock()

	// Move metadata file
	srcMeta := filepath.Join(qm.queueDir, message.ID+".json")
	dstMeta := filepath.Join(qm.bouncedDir, message.ID+".json")

	if err := os.Rename(srcMeta, dstMeta); err != nil {
		return fmt.Errorf("failed to move metadata file: %w", err)
	}

	// Move spool file
	srcSpool := message.SpoolPath
	dstSpool := filepath.Join(qm.bouncedDir, message.ID+".eml")

	if err := os.Rename(srcSpool, dstSpool); err != nil {
		return fmt.Errorf("failed to move spool file: %w", err)
	}

	// Update message paths
	message.SpoolPath = dstSpool
	message.State = StateBounced

	return nil
}

// ListMessages returns all messages in the queue
func (qm *QueueManager) ListMessages() ([]*Message, error) {
	qm.mutex.RLock()
	defer qm.mutex.RUnlock()

	var messages []*Message

	err := filepath.Walk(qm.queueDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() || filepath.Ext(path) != ".json" {
			return nil
		}

		message, err := qm.loadMessage(path)
		if err != nil {
			return err
		}

		messages = append(messages, message)
		return nil
	})

	return messages, err
}

// saveMessage saves message metadata to a JSON file
func (qm *QueueManager) saveMessage(message *Message) error {
	path := filepath.Join(qm.queueDir, message.ID+".json")
	data, err := json.MarshalIndent(message, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal message: %w", err)
	}

	if err := os.WriteFile(path, data, 0644); err != nil {
		return fmt.Errorf("failed to write message file: %w", err)
	}

	return nil
}

// loadMessage loads message metadata from a JSON file
func (qm *QueueManager) loadMessage(path string) (*Message, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read message file: %w", err)
	}

	var message Message
	if err := json.Unmarshal(data, &message); err != nil {
		return nil, fmt.Errorf("failed to unmarshal message: %w", err)
	}

	return &message, nil
}

// GetQueueStats returns statistics about the queue
func (qm *QueueManager) GetQueueStats() (map[string]int, error) {
	qm.mutex.RLock()
	defer qm.mutex.RUnlock()

	stats := map[string]int{
		"pending":   0,
		"retry":     0,
		"delivered": 0,
		"bounced":   0,
	}

	// Count messages in queue directory
	err := filepath.Walk(qm.queueDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() || filepath.Ext(path) != ".json" {
			return nil
		}

		message, err := qm.loadMessage(path)
		if err != nil {
			return err
		}

		stats[string(message.State)]++
		return nil
	})

	if err != nil {
		return nil, err
	}

	// Count delivered messages
	deliveredFiles, err := filepath.Glob(filepath.Join(qm.deliveredDir, "*.json"))
	if err == nil {
		stats["delivered"] = len(deliveredFiles)
	}

	// Count bounced messages
	bouncedFiles, err := filepath.Glob(filepath.Join(qm.bouncedDir, "*.json"))
	if err == nil {
		stats["bounced"] = len(bouncedFiles)
	}

	return stats, nil
}

// Cleanup removes old delivered and bounced messages
func (qm *QueueManager) Cleanup(olderThan time.Duration) error {
	qm.mutex.Lock()
	defer qm.mutex.Unlock()

	cutoff := time.Now().Add(-olderThan)

	// Cleanup delivered messages
	err := filepath.Walk(qm.deliveredDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() {
			return nil
		}

		if info.ModTime().Before(cutoff) {
			return os.Remove(path)
		}

		return nil
	})

	if err != nil {
		return err
	}

	// Cleanup bounced messages
	err = filepath.Walk(qm.bouncedDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if info.IsDir() {
			return nil
		}

		if info.ModTime().Before(cutoff) {
			return os.Remove(path)
		}

		return nil
	})

	return err
}
