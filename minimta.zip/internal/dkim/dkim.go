package dkim

import (
	"bytes"
	"crypto"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"os"

	"github.com/emersion/go-msgauth/dkim"
)

// Signer handles DKIM signing of email messages
type Signer struct {
	domain     string
	selector   string
	algorithm  string
	privateKey crypto.PrivateKey
}

// NewSigner creates a new DKIM signer
func NewSigner(domain, selector, algorithm, keyPath string) (*Signer, error) {
	// Load private key
	privateKey, err := loadPrivateKey(keyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load private key: %w", err)
	}

	// Validate algorithm
	if algorithm != "rsa-sha256" && algorithm != "rsa-sha1" {
		return nil, fmt.Errorf("unsupported algorithm: %s", algorithm)
	}

	return &Signer{
		domain:     domain,
		selector:   selector,
		algorithm:  algorithm,
		privateKey: privateKey,
	}, nil
}

// SignMessage signs an email message with DKIM
func (s *Signer) SignMessage(messageData []byte) ([]byte, error) {
	// Create DKIM options
	options := &dkim.SignOptions{
		Domain:   s.domain,
		Selector: s.selector,
		Signer:   s.privateKey.(crypto.Signer),
	}

	// Set algorithm
	switch s.algorithm {
	case "rsa-sha256":
		options.Hash = crypto.SHA256
	case "rsa-sha1":
		options.Hash = crypto.SHA1
	}

	// Sign the message
	var buf bytes.Buffer
	reader := bytes.NewReader(messageData)
	err := dkim.Sign(&buf, reader, options)
	if err != nil {
		return nil, fmt.Errorf("failed to sign message: %w", err)
	}

	return buf.Bytes(), nil
}

// VerifyMessage verifies a DKIM signature on a message
func (s *Signer) VerifyMessage(messageData []byte) error {
	// Verify the signature
	reader := bytes.NewReader(messageData)
	_, err := dkim.Verify(reader)
	if err != nil {
		return fmt.Errorf("DKIM verification failed: %w", err)
	}

	return nil
}

// GetPublicKey returns the public key for DNS TXT record
func (s *Signer) GetPublicKey() (string, error) {
	// Extract public key from private key
	var publicKey crypto.PublicKey
	switch key := s.privateKey.(type) {
	case *rsa.PrivateKey:
		publicKey = &key.PublicKey
	default:
		return "", fmt.Errorf("unsupported private key type")
	}

	// Encode public key as DER
	der, err := x509.MarshalPKIXPublicKey(publicKey)
	if err != nil {
		return "", fmt.Errorf("failed to marshal public key: %w", err)
	}

	// Convert to base64
	return fmt.Sprintf("v=DKIM1; k=rsa; p=%s", encodeBase64(der)), nil
}

// loadPrivateKey loads a private key from file
func loadPrivateKey(keyPath string) (crypto.PrivateKey, error) {
	// Read key file
	data, err := os.ReadFile(keyPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read key file: %w", err)
	}

	// Parse PEM block
	block, _ := pem.Decode(data)
	if block == nil {
		return nil, fmt.Errorf("failed to decode PEM block")
	}

	// Parse private key based on type
	switch block.Type {
	case "RSA PRIVATE KEY":
		return x509.ParsePKCS1PrivateKey(block.Bytes)
	case "PRIVATE KEY":
		return x509.ParsePKCS8PrivateKey(block.Bytes)
	default:
		return nil, fmt.Errorf("unsupported private key type: %s", block.Type)
	}
}

// encodeBase64 encodes data as base64 string
func encodeBase64(data []byte) string {
	// Simple base64 encoding without padding
	const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

	result := make([]byte, 0, len(data)*4/3+4)

	for i := 0; i < len(data); i += 3 {
		// Get 3 bytes
		b1 := data[i]
		var b2, b3 byte
		if i+1 < len(data) {
			b2 = data[i+1]
		}
		if i+2 < len(data) {
			b3 = data[i+2]
		}

		// Convert to 4 base64 characters
		result = append(result, charset[b1>>2])
		result = append(result, charset[((b1&0x03)<<4)|(b2>>4)])

		if i+1 < len(data) {
			result = append(result, charset[((b2&0x0f)<<2)|(b3>>6)])
		} else {
			result = append(result, '=')
		}

		if i+2 < len(data) {
			result = append(result, charset[b3&0x3f])
		} else {
			result = append(result, '=')
		}
	}

	return string(result)
}

// GenerateKeyPair generates a new RSA key pair for DKIM
func GenerateKeyPair(bits int) (*rsa.PrivateKey, error) {
	return rsa.GenerateKey(nil, bits)
}

// SavePrivateKey saves a private key to a file
func SavePrivateKey(key *rsa.PrivateKey, filename string) error {
	// Encode private key as PEM
	der, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return fmt.Errorf("failed to marshal private key: %w", err)
	}

	block := &pem.Block{
		Type:  "PRIVATE KEY",
		Bytes: der,
	}

	// Write to file
	file, err := os.Create(filename)
	if err != nil {
		return fmt.Errorf("failed to create key file: %w", err)
	}
	defer file.Close()

	if err := pem.Encode(file, block); err != nil {
		return fmt.Errorf("failed to encode private key: %w", err)
	}

	return nil
}

// SavePublicKey saves a public key to a file
func SavePublicKey(key *rsa.PublicKey, filename string) error {
	// Encode public key as PEM
	der, err := x509.MarshalPKIXPublicKey(key)
	if err != nil {
		return fmt.Errorf("failed to marshal public key: %w", err)
	}

	block := &pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: der,
	}

	// Write to file
	file, err := os.Create(filename)
	if err != nil {
		return fmt.Errorf("failed to create key file: %w", err)
	}
	defer file.Close()

	if err := pem.Encode(file, block); err != nil {
		return fmt.Errorf("failed to encode public key: %w", err)
	}

	return nil
}
