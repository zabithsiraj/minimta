package main

import (
	"fmt"
	"os"
	"text/tabwriter"
	"time"

	"minimta/internal/config"
	"minimta/internal/log"
	"minimta/internal/queue"

	"github.com/spf13/cobra"
)

var (
	configPath string
	logLevel   string
	devMode    bool
)

func main() {
	var rootCmd = &cobra.Command{
		Use:   "mta",
		Short: "MiniMTA CLI tool",
		Long:  "MiniMTA CLI tool for managing the message queue",
	}

	// Global flags
	rootCmd.PersistentFlags().StringVar(&configPath, "config", "config.yaml", "Path to configuration file")
	rootCmd.PersistentFlags().StringVar(&logLevel, "log-level", "info", "Log level (debug, info, warn, error)")
	rootCmd.PersistentFlags().BoolVar(&devMode, "dev", false, "Enable development mode")

	// Queue commands
	rootCmd.AddCommand(queueCmd)

	if err := rootCmd.Execute(); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

var queueCmd = &cobra.Command{
	Use:   "queue",
	Short: "Manage message queue",
	Long:  "Manage the message queue",
}

var queueListCmd = &cobra.Command{
	Use:   "list",
	Short: "List queued messages",
	Long:  "List all messages in the queue",
	Run: func(cmd *cobra.Command, args []string) {
		runQueueList()
	},
}

var queueRetryCmd = &cobra.Command{
	Use:   "retry <message-id>",
	Short: "Force retry of a message",
	Long:  "Force retry of a specific message",
	Args:  cobra.ExactArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		runQueueRetry(args[0])
	},
}

var queueStatsCmd = &cobra.Command{
	Use:   "stats",
	Short: "Show queue statistics",
	Long:  "Show statistics about the message queue",
	Run: func(cmd *cobra.Command, args []string) {
		runQueueStats()
	},
}

func init() {
	queueCmd.AddCommand(queueListCmd)
	queueCmd.AddCommand(queueRetryCmd)
	queueCmd.AddCommand(queueStatsCmd)
}

func runQueueList() {
	// Initialize logging
	if devMode {
		if err := log.InitDevelopment(logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize development logger: %v\n", err)
			os.Exit(1)
		}
	} else {
		if err := log.Init(logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize logger: %v\n", err)
			os.Exit(1)
		}
	}
	defer log.Sync()

	// Load configuration
	cfg, err := config.Load(configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to load configuration: %v\n", err)
		os.Exit(1)
	}

	// Initialize queue manager
	queueManager := queue.NewQueueManager(
		cfg.Queue.QueueDir,
		cfg.Queue.SpoolDir,
		cfg.Queue.DeliveredDir,
		cfg.Queue.BouncedDir,
	)

	// Get all messages
	messages, err := queueManager.ListMessages()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to list messages: %v\n", err)
		os.Exit(1)
	}

	if len(messages) == 0 {
		fmt.Println("No messages in queue")
		return
	}

	// Create tabwriter for formatted output
	w := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
	fmt.Fprintln(w, "ID\tFROM\tRECIPIENTS\tSTATE\tATTEMPTS\tNEXT TRY\tCREATED")
	fmt.Fprintln(w, "---\t----\t----------\t-----\t--------\t--------\t-------")

	for _, msg := range messages {
		recipients := fmt.Sprintf("%d recipients", len(msg.Rcpts))
		if len(msg.Rcpts) == 1 {
			recipients = msg.Rcpts[0]
		}

		nextTry := "-"
		if !msg.NextTry.IsZero() {
			nextTry = msg.NextTry.Format("2006-01-02 15:04:05")
		}

		fmt.Fprintf(w, "%s\t%s\t%s\t%s\t%d\t%s\t%s\n",
			msg.ID,
			msg.From,
			recipients,
			msg.State,
			msg.Attempts,
			nextTry,
			msg.CreatedAt.Format("2006-01-02 15:04:05"),
		)
	}

	w.Flush()
}

func runQueueRetry(messageID string) {
	// Initialize logging
	if devMode {
		if err := log.InitDevelopment(logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize development logger: %v\n", err)
			os.Exit(1)
		}
	} else {
		if err := log.Init(logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize logger: %v\n", err)
			os.Exit(1)
		}
	}
	defer log.Sync()

	// Load configuration
	cfg, err := config.Load(configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to load configuration: %v\n", err)
		os.Exit(1)
	}

	// Initialize queue manager
	queueManager := queue.NewQueueManager(
		cfg.Queue.QueueDir,
		cfg.Queue.SpoolDir,
		cfg.Queue.DeliveredDir,
		cfg.Queue.BouncedDir,
	)

	// Get message
	message, err := queueManager.GetMessage(messageID)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to get message %s: %v\n", messageID, err)
		os.Exit(1)
	}

	// Reset message state to pending for immediate retry
	message.State = queue.StatePending
	message.NextTry = time.Now()
	message.Error = ""

	if err := queueManager.UpdateMessageState(message, queue.StatePending, ""); err != nil {
		fmt.Fprintf(os.Stderr, "Failed to update message state: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("Message %s scheduled for immediate retry\n", messageID)
}

func runQueueStats() {
	// Initialize logging
	if devMode {
		if err := log.InitDevelopment(logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize development logger: %v\n", err)
			os.Exit(1)
		}
	} else {
		if err := log.Init(logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize logger: %v\n", err)
			os.Exit(1)
		}
	}
	defer log.Sync()

	// Load configuration
	cfg, err := config.Load(configPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to load configuration: %v\n", err)
		os.Exit(1)
	}

	// Initialize queue manager
	queueManager := queue.NewQueueManager(
		cfg.Queue.QueueDir,
		cfg.Queue.SpoolDir,
		cfg.Queue.DeliveredDir,
		cfg.Queue.BouncedDir,
	)

	// Get queue statistics
	stats, err := queueManager.GetQueueStats()
	if err != nil {
		fmt.Fprintf(os.Stderr, "Failed to get queue statistics: %v\n", err)
		os.Exit(1)
	}

	fmt.Println("Queue Statistics:")
	fmt.Println("=================")
	fmt.Printf("Pending:   %d\n", stats["pending"])
	fmt.Printf("Retry:     %d\n", stats["retry"])
	fmt.Printf("Delivered: %d\n", stats["delivered"])
	fmt.Printf("Bounced:   %d\n", stats["bounced"])
	fmt.Printf("Total:     %d\n", stats["pending"]+stats["retry"]+stats["delivered"]+stats["bounced"])
}
