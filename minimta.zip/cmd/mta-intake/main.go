package main

import (
	"crypto/tls"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"minimta/internal/auth"
	"minimta/internal/config"
	"minimta/internal/dkim"
	"minimta/internal/log"
	"minimta/internal/queue"
	"minimta/internal/smtpserver"

	"go.uber.org/zap"
)

func main() {
	var (
		configPath = flag.String("config", "config.yaml", "Path to configuration file")
		logLevel   = flag.String("log-level", "info", "Log level (debug, info, warn, error)")
		devMode    = flag.Bool("dev", false, "Enable development mode")
	)
	flag.Parse()

	// Initialize logging
	if *devMode {
		if err := log.InitDevelopment(*logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize development logger: %v\n", err)
			os.Exit(1)
		}
	} else {
		if err := log.Init(*logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize logger: %v\n", err)
			os.Exit(1)
		}
	}
	defer log.Sync()

	log.Info("Starting MiniMTA Intake Server")

	// Load configuration
	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatal("Failed to load configuration", zap.Error(err))
	}

	log.Info("Configuration loaded",
		zap.String("hostname", cfg.Server.Hostname),
		zap.String("listen_addr", cfg.Server.ListenAddr),
		zap.Int64("max_message_size", cfg.Server.MaxMsgSize))

	// Initialize authentication manager
	authManager := auth.NewAuthManager(cfg.Auth.UsersFile)
	if err := authManager.LoadUsers(); err != nil {
		log.Fatal("Failed to load users", zap.Error(err))
	}

	log.Info("Authentication manager initialized",
		zap.String("users_file", cfg.Auth.UsersFile))

	// Initialize queue manager
	queueManager := queue.NewQueueManager(
		cfg.Queue.QueueDir,
		cfg.Queue.SpoolDir,
		cfg.Queue.DeliveredDir,
		cfg.Queue.BouncedDir,
	)

	if err := queueManager.Initialize(); err != nil {
		log.Fatal("Failed to initialize queue manager", zap.Error(err))
	}

	log.Info("Queue manager initialized",
		zap.String("queue_dir", cfg.Queue.QueueDir),
		zap.String("spool_dir", cfg.Queue.SpoolDir))

	// Initialize DKIM signer
	var dkimSigner *dkim.Signer
	if cfg.DKIM.KeyPath != "" {
		dkimSigner, err = dkim.NewSigner(
			cfg.DKIM.Domain,
			cfg.DKIM.Selector,
			cfg.DKIM.Algorithm,
			cfg.DKIM.KeyPath,
		)
		if err != nil {
			log.Fatal("Failed to initialize DKIM signer", zap.Error(err))
		}

		log.Info("DKIM signer initialized",
			zap.String("domain", cfg.DKIM.Domain),
			zap.String("selector", cfg.DKIM.Selector),
			zap.String("algorithm", cfg.DKIM.Algorithm))
	} else {
		log.Warn("DKIM signing disabled (no key path configured)")
	}

	// Load TLS certificate
	tlsConfig, err := loadTLSConfig(cfg.TLS.CertFile, cfg.TLS.KeyFile)
	if err != nil {
		log.Fatal("Failed to load TLS configuration", zap.Error(err))
	}

	log.Info("TLS configuration loaded",
		zap.String("cert_file", cfg.TLS.CertFile),
		zap.String("key_file", cfg.TLS.KeyFile))

	// Create SMTP backend
	backend := smtpserver.NewBackend(
		authManager,
		queueManager,
		dkimSigner,
		cfg.Server.MaxMsgSize,
	)

	// Create SMTP server
	server := smtpserver.NewServer(cfg.Server.ListenAddr, backend, tlsConfig, cfg.TLS.CertFile, cfg.TLS.KeyFile)

	// Set up signal handling
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Start server in a goroutine
	go func() {
		log.Info("Starting SMTP server", zap.String("addr", cfg.Server.ListenAddr))
		if err := server.StartTLS(); err != nil {
			log.Fatal("Failed to start SMTP server", zap.Error(err))
		}
	}()

	// Wait for shutdown signal
	<-sigChan
	log.Info("Shutdown signal received")

	// Stop server
	if err := server.Stop(); err != nil {
		log.Error("Error stopping server", zap.Error(err))
	}

	log.Info("MiniMTA Intake Server stopped")
}

// loadTLSConfig loads TLS configuration from certificate files
func loadTLSConfig(certFile, keyFile string) (*tls.Config, error) {
	cert, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		return nil, fmt.Errorf("failed to load TLS certificate: %w", err)
	}

	return &tls.Config{
		Certificates: []tls.Certificate{cert},
		MinVersion:   tls.VersionTLS12,
	}, nil
}
