package main

import (
	"flag"
	"fmt"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"minimta/internal/config"
	"minimta/internal/delivery"
	"minimta/internal/log"
	"minimta/internal/queue"

	"go.uber.org/zap"
)

func main() {
	var (
		configPath = flag.String("config", "config.yaml", "Path to configuration file")
		logLevel   = flag.String("log-level", "info", "Log level (debug, info, warn, error)")
		devMode    = flag.Bool("dev", false, "Enable development mode")
	)
	flag.Parse()

	// Initialize logging
	if *devMode {
		if err := log.InitDevelopment(*logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize development logger: %v\n", err)
			os.Exit(1)
		}
	} else {
		if err := log.Init(*logLevel); err != nil {
			fmt.Fprintf(os.Stderr, "Failed to initialize logger: %v\n", err)
			os.Exit(1)
		}
	}
	defer log.Sync()

	log.Info("Starting MiniMTA Delivery Worker")

	// Load configuration
	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatal("Failed to load configuration", zap.Error(err))
	}

	log.Info("Configuration loaded",
		zap.Int("max_retries", cfg.Delivery.MaxRetries),
		zap.Duration("retry_interval", cfg.Delivery.RetryInterval),
		zap.Duration("connect_timeout", cfg.Delivery.ConnectTimeout),
		zap.Int("max_concurrency", cfg.Delivery.MaxConcurrency))

	// Initialize queue manager
	queueManager := queue.NewQueueManager(
		cfg.Queue.QueueDir,
		cfg.Queue.SpoolDir,
		cfg.Queue.DeliveredDir,
		cfg.Queue.BouncedDir,
	)

	if err := queueManager.Initialize(); err != nil {
		log.Fatal("Failed to initialize queue manager", zap.Error(err))
	}

	log.Info("Queue manager initialized")

	// Initialize delivery manager
	deliveryManager := delivery.NewDeliveryManager(
		cfg.Delivery.ConnectTimeout,
		cfg.Delivery.CommandTimeout,
		cfg.Delivery.TLSOptional,
		cfg.Delivery.MaxRetries,
		cfg.Delivery.RetryInterval,
		cfg.Delivery.MaxRetryDelay,
	)

	log.Info("Delivery manager initialized")

	// Set up signal handling
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	// Create worker pool
	workerPool := make(chan struct{}, cfg.Delivery.MaxConcurrency)
	var wg sync.WaitGroup

	// Start main worker loop
	go func() {
		ticker := time.NewTicker(cfg.Delivery.WorkerInterval)
		defer ticker.Stop()

		for {
			select {
			case <-sigChan:
				log.Info("Shutdown signal received")
				return
			case <-ticker.C:
				// Process pending messages
				if err := processMessages(queueManager, deliveryManager, workerPool, &wg, cfg); err != nil {
					log.Error("Error processing messages", zap.Error(err))
				}
			}
		}
	}()

	// Wait for shutdown signal
	<-sigChan
	log.Info("Shutdown signal received")

	// Wait for all workers to finish
	log.Info("Waiting for workers to finish...")
	wg.Wait()

	log.Info("MiniMTA Delivery Worker stopped")
}

// processMessages processes pending messages from the queue
func processMessages(queueManager *queue.QueueManager, deliveryManager *delivery.DeliveryManager, workerPool chan struct{}, wg *sync.WaitGroup, cfg *config.Config) error {
	// Get pending messages
	messages, err := queueManager.GetPendingMessages()
	if err != nil {
		return fmt.Errorf("failed to get pending messages: %w", err)
	}

	if len(messages) == 0 {
		return nil
	}

	log.Info("Processing messages", zap.Int("count", len(messages)))

	// Process each message
	for _, message := range messages {
		// Acquire worker slot
		workerPool <- struct{}{}
		wg.Add(1)

		go func(msg *queue.Message) {
			defer func() {
				<-workerPool
				wg.Done()
			}()

			processMessage(queueManager, deliveryManager, msg, cfg)
		}(message)
	}

	return nil
}

// processMessage processes a single message
func processMessage(queueManager *queue.QueueManager, deliveryManager *delivery.DeliveryManager, message *queue.Message, cfg *config.Config) {
	log.Info("Processing message",
		zap.String("message_id", message.ID),
		zap.String("from", message.From),
		zap.Strings("recipients", message.Rcpts),
		zap.Int("attempts", message.Attempts))

	// Get message data
	messageData, err := queueManager.GetMessageData(message)
	if err != nil {
		log.Error("Failed to get message data",
			zap.String("message_id", message.ID),
			zap.Error(err))

		// Move to bounced
		if err := queueManager.MoveToBounced(message); err != nil {
			log.Error("Failed to move message to bounced",
				zap.String("message_id", message.ID),
				zap.Error(err))
		}
		return
	}

	// Attempt delivery
	result := deliveryManager.DeliverMessage(message.From, message.Rcpts, messageData)

	if result.Success {
		// Delivery successful
		log.Info("Message delivered successfully",
			zap.String("message_id", message.ID))

		if err := queueManager.MoveToDelivered(message); err != nil {
			log.Error("Failed to move message to delivered",
				zap.String("message_id", message.ID),
				zap.Error(err))
		}
	} else {
		// Delivery failed
		log.Error("Message delivery failed",
			zap.String("message_id", message.ID),
			zap.String("error", result.Error))

		// Check if we should retry
		if deliveryManager.ShouldRetry(fmt.Errorf(result.Error), message.Attempts+1) {
			// Calculate retry delay
			retryDelay := deliveryManager.CalculateRetryDelay(message.Attempts + 1)

			log.Info("Scheduling retry",
				zap.String("message_id", message.ID),
				zap.Int("attempt", message.Attempts+1),
				zap.Duration("retry_delay", retryDelay))

			// Increment attempts and schedule retry
			if err := queueManager.IncrementAttempts(message, retryDelay); err != nil {
				log.Error("Failed to increment attempts",
					zap.String("message_id", message.ID),
					zap.Error(err))
			}
		} else {
			// Max retries exceeded or permanent failure
			log.Error("Message failed permanently",
				zap.String("message_id", message.ID),
				zap.String("error", result.Error))

			// Update message state
			if err := queueManager.UpdateMessageState(message, queue.StateBounced, result.Error); err != nil {
				log.Error("Failed to update message state",
					zap.String("message_id", message.ID),
					zap.Error(err))
			}

			// Move to bounced
			if err := queueManager.MoveToBounced(message); err != nil {
				log.Error("Failed to move message to bounced",
					zap.String("message_id", message.ID),
					zap.Error(err))
			}
		}
	}
}
