#!/bin/bash

# MiniMTA Installation Script
# This script installs and configures MiniMTA SMTP server

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/minimta"
SERVICE_USER="minimta"
CONFIG_DIR="/etc/minimta"
LOG_DIR="/var/log/minimta"

echo -e "${BLUE}MiniMTA Installation Script${NC}"
echo "================================"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root (use sudo)${NC}"
   exit 1
fi

# Install all prerequisites
echo -e "${YELLOW}Installing prerequisites...${NC}"

# Detect OS and install prerequisites
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Ubuntu/Debian
    if command -v apt-get &> /dev/null; then
        echo -e "${YELLOW}Detected Ubuntu/Debian system${NC}"
        apt-get update
        apt-get install -y golang-go openssl curl git build-essential
    # CentOS/RHEL
    elif command -v yum &> /dev/null; then
        echo -e "${YELLOW}Detected CentOS/RHEL system${NC}"
        yum install -y golang openssl curl git gcc make
    # Fedora
    elif command -v dnf &> /dev/null; then
        echo -e "${YELLOW}Detected Fedora system${NC}"
        dnf install -y golang openssl curl git gcc make
    # Arch Linux
    elif command -v pacman &> /dev/null; then
        echo -e "${YELLOW}Detected Arch Linux system${NC}"
        pacman -S --noconfirm go openssl curl git base-devel
    else
        echo -e "${RED}Unsupported Linux distribution. Please install Go, OpenSSL, curl, and git manually.${NC}"
        exit 1
    fi
else
    echo -e "${RED}Unsupported operating system. Please install Go, OpenSSL, curl, and git manually.${NC}"
    exit 1
fi

# Verify Go installation
if ! command -v go &> /dev/null; then
    echo -e "${RED}Failed to install Go. Please install Go manually.${NC}"
    exit 1
fi

echo -e "${GREEN}Prerequisites installed successfully:${NC}"
echo -e "  Go: $(go version)"
echo -e "  OpenSSL: $(openssl version)"
echo -e "  Git: $(git --version)"
echo -e "  Curl: $(curl --version | head -n1)"

# Create service user
if ! id "$SERVICE_USER" &>/dev/null; then
    echo -e "${YELLOW}Creating service user: $SERVICE_USER${NC}"
    useradd -r -s /bin/false -d "$INSTALL_DIR" "$SERVICE_USER"
fi

# Create directories
echo -e "${YELLOW}Creating directories...${NC}"
mkdir -p "$INSTALL_DIR"/{bin,queue,spool,delivered,bounced}
mkdir -p "$CONFIG_DIR"
mkdir -p "$LOG_DIR"

# Build the application
echo -e "${YELLOW}Building MiniMTA...${NC}"
go mod tidy
go build -o "$INSTALL_DIR/bin/mta-intake" cmd/mta-intake/main.go
go build -o "$INSTALL_DIR/bin/mta-deliver" cmd/mta-deliver/main.go
go build -o "$INSTALL_DIR/bin/mta-cli" cmd/mta-cli/main.go

# Set permissions
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
chown -R "$SERVICE_USER:$SERVICE_USER" "$LOG_DIR"
chmod +x "$INSTALL_DIR/bin"/*

# Create configuration files
echo -e "${YELLOW}Creating configuration files...${NC}"

# Copy example config
cp config.yaml.example "$CONFIG_DIR/config.yaml" 2>/dev/null || {
    # Create default config if example doesn't exist
    cat > "$CONFIG_DIR/config.yaml" << 'EOF'
# MiniMTA Configuration File

# Server configuration
server:
  hostname: "mail.example.com"
  listen_addr: "0.0.0.0:587"
  max_message_size: 10485760  # 10MB in bytes
  read_timeout: 60           # seconds
  write_timeout: 60         # seconds

# TLS configuration
tls:
  cert_file: "/etc/minimta/certs/server.crt"
  key_file: "/etc/minimta/certs/server.key"

# DKIM configuration (disabled by default)
# dkim:
#   key_path: "/etc/minimta/dkim.key"
#   selector: "default"

# Queue configuration
queue:
  queue_dir: "/opt/minimta/queue"
  spool_dir: "/opt/minimta/spool"
  delivered_dir: "/opt/minimta/delivered"
  bounced_dir: "/opt/minimta/bounced"

# Delivery configuration
delivery:
  max_retries: 5
  retry_delay: "5m"
  max_retry_delay: "1h"
  connection_timeout: "30s"
  command_timeout: "5m"
EOF
}

# Create users file
cat > "$CONFIG_DIR/users.json" << 'EOF'
[
  {
    "username": "admin",
    "password": "admin123",
    "email": "admin@example.com",
    "active": true
  }
]
EOF

# Create SSL certificates directory and generate self-signed cert
mkdir -p "$CONFIG_DIR/certs"
if [[ ! -f "$CONFIG_DIR/certs/server.crt" ]]; then
    echo -e "${YELLOW}Generating self-signed SSL certificate...${NC}"
    openssl req -x509 -newkey rsa:2048 -keyout "$CONFIG_DIR/certs/server.key" -out "$CONFIG_DIR/certs/server.crt" -days 365 -nodes -subj "/CN=localhost"
    chmod 600 "$CONFIG_DIR/certs/server.key"
    chmod 644 "$CONFIG_DIR/certs/server.crt"
fi

# Set ownership
chown -R "$SERVICE_USER:$SERVICE_USER" "$CONFIG_DIR"

# Create systemd service files
echo -e "${YELLOW}Creating systemd services...${NC}"

# MTA Intake Service
cat > /etc/systemd/system/mta-intake.service << EOF
[Unit]
Description=MiniMTA Intake Server
After=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/bin/mta-intake -config $CONFIG_DIR/config.yaml -log-level info
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=mta-intake

[Install]
WantedBy=multi-user.target
EOF

# MTA Deliver Service
cat > /etc/systemd/system/mta-deliver.service << EOF
[Unit]
Description=MiniMTA Delivery Worker
After=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/bin/mta-deliver -config $CONFIG_DIR/config.yaml -log-level info
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=mta-deliver

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable services
systemctl daemon-reload
systemctl enable mta-intake.service
systemctl enable mta-deliver.service

# Create CLI symlink
ln -sf "$INSTALL_DIR/bin/mta-cli" /usr/local/bin/mta

echo -e "${GREEN}Installation completed successfully!${NC}"
echo ""
echo -e "${BLUE}Configuration:${NC}"
echo "  Config directory: $CONFIG_DIR"
echo "  Install directory: $INSTALL_DIR"
echo "  Log directory: $LOG_DIR"
echo "  Service user: $SERVICE_USER"
echo ""
echo -e "${BLUE}Services:${NC}"
echo "  mta-intake.service (SMTP submission server)"
echo "  mta-deliver.service (Email delivery worker)"
echo ""
echo -e "${BLUE}Commands:${NC}"
echo "  Start services: systemctl start mta-intake mta-deliver"
echo "  Stop services:  systemctl stop mta-intake mta-deliver"
echo "  View logs:      journalctl -u mta-intake -f"
echo "  Queue management: mta queue list"
echo ""
echo -e "${YELLOW}Default credentials:${NC}"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Edit $CONFIG_DIR/config.yaml to configure your server"
echo "2. Edit $CONFIG_DIR/users.json to add/modify users"
echo "3. Start the services: systemctl start mta-intake mta-deliver"
echo "4. Check status: systemctl status mta-intake mta-deliver"
